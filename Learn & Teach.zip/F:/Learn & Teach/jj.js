$('.carousel').carousel()

$('.carousel').carousel({
    interval: 2000
  })